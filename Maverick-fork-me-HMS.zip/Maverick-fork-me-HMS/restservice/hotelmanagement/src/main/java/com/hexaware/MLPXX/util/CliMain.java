package com.hexaware.MLPXX.util;
import java.util.Scanner;
import com.hexaware.MLPXX.factory.RoomFactory;
import com.hexaware.MLPXX.model.Room;
/**
 * CliMain used as Client interface for java coading.
 * @author hexware
 */
class CliMain {
  private Scanner option = new Scanner(System.in, "UTF-8");
/**
 * mainRoom method  used to display the option we had in the application.
 */
  private void mainRoom() {
    System.out.println("Hotel Management System");
    System.out.println("-----------------------");
    System.out.println("1. Show Room");
    System.out.println("2. Exit");
    mainRoomDetails();
  }
/**
 * mainRoomDetails method  process the option selected from main menu.
 */
  private void mainRoomDetails() {
    try {
      System.out.println("Enter your choice:");
      int roomOption = option.nextInt();
      switch (roomOption) {
        case 1:
          showFullRoom();
          break;
        case 2:
          Runtime.getRuntime().halt(0);
        default:
          System.out.println("Choose either 1 or 2");
      }
    } catch (Exception e) {
      e.printStackTrace();
      System.out.println("enter a valid value");
    }
    option.nextLine();
    mainRoom();
  }
/**
 * showFullRoom method  display the room details stored in database.
 */
  private void showFullRoom() {
    Room[] room = RoomFactory.showRoom();
    System.out.println("Room_Id");
    for (Room m : room) {
      System.out.println(m.getRoomNo());
    }
  }
/**
 * main method  is the basic entry point for the application.
 * @param args used to get the user input.
 */
  public static void main(final String[] args) {
    final CliMain mainObj = new CliMain();
    mainObj.mainRoom();
  }
}
