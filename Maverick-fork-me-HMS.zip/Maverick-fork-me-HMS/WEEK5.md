# Week #5: Course Materials

The objective of week #5 is to complete the Web application design. 

## WebServers & WebServices

## HTML5, CSS3, JavaScript/TypeScript

## Angular

## AWS Basics