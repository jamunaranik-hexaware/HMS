# Welcome to Hexaware Maverick Training Course

  Please take a look at the following files

  * CHEATSHEET.md gives all the commands that are useful while using command line tools such as git, maven etc.
  * Week[n].md contains the structure of the course on a week-by-week basis

  