# Week #4: Course Materials

The objective of week #4 is to complete the Cli implementation for all the functionalities and add Test cases using Junit and Jmockit. 

## Java

## Junit

## Jmockit

### Work on adding unit tests
    * One person to make mvn package succeed - add Room tests
    * Others to add tests for booking etc.

### Tests for the cli

### Basic tests
    * Invalid input for the data type
    * Including for the menu option
    * Apply wallet balance not sufficient
    
 
